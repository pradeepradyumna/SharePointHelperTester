﻿using Microsoft.Graph;
using SharePointHelper.Core._3._1;
using System.Threading.Tasks;

namespace SharePointHelperTester
{
    internal class Program
    {
        static async Task Main(string[] args)
        {


            AzureConfiguration configuration = new AzureConfiguration(
                "Azure ClientId", "Azure ClientSecret", "Azure TenantId", "SharePoint SiteName", "SharePoint site's endPoint");

            // Example:
            // Endpoint "https://dummyorganization.sharepoint.com"

            // "https://dummyorganization.sharepoint.com/sites/TestingSite"
            // SiteName "TestingSite" 



            SharePointService sharePointService = new SharePointService();
            
            
            DriveItem newFolderDriveItem = await sharePointService.CreateFolder(configuration, "/root/Folder1/Folder2", "Folder3");

            string downloadedPath = await sharePointService.DownloadFile(configuration, "XXXX");

            await sharePointService.SafeCreateDirectory(configuration,"/root/FolderA/FolderB");

            DriveItem movedDriveItem = await sharePointService.MoveFile(configuration,
                "/root/Folder1/dst", "dst.docx",
                "/root/Folder1/src", "src.docx");

            DriveItem copiedDriveItem = await sharePointService.CopyFile(configuration,
                "/root/Folder1/dst", "dst.docx",
                "/root/Folder1/src", "src.docx");

        }
    }
}
